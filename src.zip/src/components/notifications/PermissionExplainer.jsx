import Button from '../common/Button';
import Input from '../common/Input';
import './PermissionExplainer.css';

export default function PermissionExplainer({
  time,
  timeError,
  onTimeChange,
  onTimeBlur,
  onEnable,
  loading
}) {
  function handleSubmit(event) {
    event.preventDefault();
    onEnable();
  }

  return (
    <div className="permission-explainer">
      <h3 className="permission-explainer__title">A quiet morning forecast</h3>
      <p className="permission-explainer__text">
        WeatherBoard can ask your browser for notification permission and send a test notification.
        Background delivery at a chosen time requires a push scheduler, which this build does not
        include.
      </p>
      <ul className="permission-explainer__list">
        <li>Permission is requested only when you choose.</li>
        <li>You can send a test notification to confirm it works.</li>
        <li>No marketing, no account, no tracking.</li>
        <li>You can turn it off whenever you want.</li>
      </ul>

      <form className="permission-explainer__form" onSubmit={handleSubmit} noValidate>
        <Input
          label="Reminder time"
          type="time"
          value={time}
          onChange={(event) => onTimeChange(event.target.value)}
          onBlur={onTimeBlur}
          error={timeError}
          hint="The next browser prompt will ask for notification permission."
        />
        <Button type="submit" loading={loading}>
          Enable notifications
        </Button>
      </form>
    </div>
  );
}
