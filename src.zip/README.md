# WeatherBoard

WeatherBoard is a responsive, installable weather dashboard built with React, Rematch, and plain CSS. It shows current conditions and a five-day forecast, supports saved cities, persists your last viewed city, works with a light or dark theme, and includes an optional daily reminder with a visible delivery mode.

## Features

- Debounced city search with keyboard navigation and accessible suggestions.
- Current temperature, condition, humidity, wind, and an animated weather icon.
- Five-day forecast with daily highs and lows.
- Celsius and Fahrenheit switching with instant conversion.
- Light and dark themes with the system preference as the default, persisted across visits.
- Up to five saved cities with duplicate protection and a confirmation dialog.
- Last viewed city and weather restored from local storage.
- Offline detection, a clear offline banner, cached weather fallback, and automatic refresh on reconnect.
- OpenWeatherMap primary data with an automatic Open-Meteo fallback for rate-limit, authentication, and server errors.
- Installable PWA with a manifest and service worker.
- Daily reminder using Periodic Background Sync when the browser and install support it, with a foreground timer fallback and a visible delivery mode.
- Notification permission explainer, reminder time validation, and test notifications.
- Inline validation, loading states, error states, and retry actions.
- Responsive layout with reduced-motion support and visible focus styles.

## Stack

- React 19
- Rematch 2 and React Redux
- Vite 8
- Plain CSS
- Hand-written service worker
- No UI kit, chart library, or state-management add-ons

## Getting started

Requirements: Node.js 20.19 or newer.

```bash
npm install
```

Create a `.env` file from `.env.example` and add an OpenWeatherMap API key:

```bash
VITE_OPENWEATHER_API_KEY=your_openweathermap_api_key
```

Then start the development server:

```bash
npm run dev
```

The key needs access to the free Geocoding API, Current Weather API, and 5 Day / 3 Hour Forecast API.

## Scripts

```bash
npm run dev      # development server
npm run build    # production build in dist/
npm run preview  # serve the production build locally
```

The service worker only registers in a production build. Use `npm run preview` to test installation, offline behavior, and notifications locally.

## Deployment

### Vercel

1. Import the repository into Vercel.
2. Keep the default Vite settings: build command `npm run build`, output directory `dist`.
3. Add `VITE_OPENWEATHER_API_KEY` under Project Settings → Environment Variables.
4. Redeploy after changing environment variables.

`vercel.json` adds a content security policy and standard security headers. The app needs HTTPS for service worker registration and notifications in production.

## API behavior

- City search uses OpenWeatherMap Geocoding.
- Weather uses OpenWeatherMap Current Weather and 5 Day / 3 Hour Forecast.
- The forecast is grouped into five daily summaries using the city's UTC offset from the forecast response.
- If OpenWeatherMap weather requests fail with a rate limit, authentication error, or server error, the app requests current conditions and a five-day forecast from Open-Meteo instead.
- Network, timeout, offline, and not-found errors are shown separately with retry guidance.
- All API responses are validated and normalized before they reach the UI.

## Offline and PWA

The service worker in `public/sw.js`:

- Pre-caches the manifest, icons, `index.html`, and the hashed JavaScript and CSS referenced by the production HTML.
- Uses cache-first handling for same-origin static files.
- Uses network-first handling for weather requests with a cached fallback.
- Deletes shell and weather caches from older versions on activation while keeping the reminder configuration cache.
- Handles `periodicsync`, `push`, and `notificationclick` events.

The app also stores the last successful weather response in local storage so the last city remains available offline. Search is intentionally disabled while offline.

## Notifications

WeatherBoard explains the permission request before triggering it. The reminder time is validated and persisted, and the service worker can display a test notification. Notification permission is only requested after a user action.

Scheduled background delivery is not claimed by this build. Delivering a notification at a chosen time without the app open requires a push service, a scheduler, or periodic background sync. The reminder card states this directly instead of promising delivery that the browser cannot guarantee on its own.

## Architecture

```text
src/
  components/
    common/         reusable UI primitives
    search/         city search and suggestions
    weather/        current weather and forecast
    favourites/     saved cities
    notifications/  reminder settings and permission explainer
    layout/         header, footer, offline banner
  hooks/            debounce, online status, persisted UI state
  services/         API, notifications, service worker registration
  store/
    models/         alert, city, weather, favourites, settings, reminder
  styles/           design tokens and global styles
  utils/            constants, validation, formatting, storage, mapping
```

Rematch models hold all runtime state. Network access stays in `src/services`, response normalization stays in `src/utils/weatherMapper.js`, and components read state through selectors.

## Local storage keys

- `weatherboard-favourites`
- `weatherboard-settings`
- `weatherboard-reminder`
- `weatherboard-last-weather`
- `weatherboard-favourites-open`

Storage reads and writes are wrapped in error handling. If local storage is unavailable, the app keeps working for the current session and tells the user that persistence is unavailable.

## Verification

The production build was checked in a headless Edge session at 375 px, 768 px, 1024 px, and 1280 px widths:

- Live OpenWeatherMap geocoding, current weather, and forecast responses mapped successfully.
- Open-Meteo responses mapped successfully and passed the same shape validation.
- Search debounce, suggestions, selection, and weather refresh worked.
- Unit and theme toggles updated the UI and persisted.
- Favourite add, remove, confirmation dialog, and toast notifications worked. Duplicate saved cities were collapsed on load.
- Saved-city switching updated the search field and current weather. It was disabled offline while the saved weather stayed visible.
- Offline banner, disabled search, saved-weather fallback, and automatic refresh on reconnect worked.
- Simulated OpenWeatherMap `429` responses fell back to Open-Meteo and showed the fallback banner.
- Reminder validation, permission-granted UI, enable/disable persistence, time updates, and test notifications worked. The denied state showed blocked guidance without duplicate errors.
- The layout had no horizontal overflow. The forecast used rows on smaller screens and five columns from 1024 px.
- The service worker registered, pre-cached the generated JavaScript and CSS, created versioned shell and weather caches, and removed the previous cache version.
- No browser console errors or uncaught page errors were observed.

## Known limitations

- Vite exposes `VITE_OPENWEATHER_API_KEY` to the client bundle. For a high-traffic production deployment, proxy OpenWeatherMap requests through a server and keep the key server-side.
- OpenWeatherMap free-tier limits apply. The Open-Meteo fallback keeps the weather view useful when OpenWeatherMap reports a rate-limit, authentication, or server error.
- The production service worker intentionally caches the last weather responses and the current build's shell. Bump `CACHE_VERSION` in `public/sw.js` when changing the caching strategy.
- Background reminder delivery is not scheduled; see the Notifications section.
